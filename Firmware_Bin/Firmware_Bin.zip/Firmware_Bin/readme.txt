----------------------------------------------------------------------------------------------
V15_rc1 (13.02.22) - WARNING Release candidate/non official firmware
- Add Relatif mode for the CC ( see Arturia Minilab user manual)
- Add NRPN manager for absolut and inc/dec Values
- New screen MIDI+MISC for all the Midi in settings
	- MIDI RX
	- MIDI Mode (Absolut/NRPN/Relatif1/Relatif2)
	- MIDI Relatif CC
	- MIDI Relatif Min
	- MIDI Relatif Max
	- Screen Calibration
----------------------------------------------------------------------------------------------
V14 (29.01.22)
- Route input Jack to Output Jack (only for ES8388 codec)
	- Very funny to play with you phone connect ot the input jack
- Set the delay to go back to the master screen in a binary file /System/BackDelay.cfg
	- Just create the file and write one byte between 0 to 255 in second
	- I the file did not exist the delay is set to the default value 10s
- Add the flashdownload tool to the github

	


